from flask import Flask, request, render_template, jsonify
import pickle
import numpy as np

app = Flask(__name__)

# Load the trained model
model = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form data
        number1 = float(request.form['number1'])
        number2 = float(request.form['number2'])
        number3 = float(request.form['number3'])
        number4 = float(request.form['number4'])
        
        # Make prediction
        prediction = model.predict([[number1, number2, number3, number4]])[0]
        
        return render_template('index.html', prediction_text=f'Predicted Change: {prediction:.2f}')
    except Exception as e:
        return str(e)

if __name__ == '__main__':
    app.run(debug=True)
